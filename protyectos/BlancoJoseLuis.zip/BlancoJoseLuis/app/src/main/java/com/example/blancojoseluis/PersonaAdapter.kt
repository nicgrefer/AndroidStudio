package com.example.blancojoseluis

class PersonaAdapter () {
}