package com.example.blancojoseluis

import androidx.lifecycle.ViewModel

class NombreViewModel: ViewModel() {
    val nombre: String = ""
    var nombre by viewModels()
}